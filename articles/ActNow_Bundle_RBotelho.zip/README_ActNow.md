# Act Now: A Warning in Image and Word

![Act Now - Protest Poster](docs/act_now.png)

> **This isn’t politics. It’s survival.**  
> Trump’s authoritarian blueprint is no longer a warning—it’s in motion.  
> Our courts, our votes, our voices—they are all under siege.  
> Flood congressional phone lines. Protest quietly but forcefully.  
> Expose the enablers. Amplify the truth. Disrupt the machine.  
> History will ask what we did. Let your answer be: **everything we could.**

**Author**: Ronald J. Botelho  
**Date**: 2025-06-06  
**Repository**: [substack-archive](https://github.com/Ron573/substack-archive)

This repository includes assets and articles from Ron’s Substack series—truth-telling, system-mapping, and resistance-inspiring work meant to wake up a democracy sleepwalking into autocracy.

If you're reading this, you're not alone. You're needed.

Licensed under CC BY-NC-ND 4.0.
